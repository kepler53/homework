package com.java.first;

public class CircleArea {

}
